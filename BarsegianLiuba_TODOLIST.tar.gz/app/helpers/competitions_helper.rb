# frozen_string_literal: true

# competitions helper
module CompetitionsHelper
end
